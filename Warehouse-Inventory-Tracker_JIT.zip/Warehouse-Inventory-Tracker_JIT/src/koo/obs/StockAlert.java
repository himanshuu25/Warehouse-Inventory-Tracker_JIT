package koo.obs;

import koo.pro.Product;

public interface StockAlert {
	public void alertService(Product p);
}
